Cheaper Shotgun Shells
by randyknapp

Description:
Shotgun shells cost 1 less component to craft