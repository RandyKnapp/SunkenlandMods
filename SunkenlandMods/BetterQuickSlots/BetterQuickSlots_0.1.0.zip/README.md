Better Quick Slots
by randyknapp

Description:
Adds four additional quick slots, plus labels. Can mouse wheel scroll through quick slots, middle mouse button to use.