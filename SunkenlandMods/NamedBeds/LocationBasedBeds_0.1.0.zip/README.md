Location Based Beds
by randyknapp

Description:
When respawning, beds are named for the location they are closest to.