Clock Fix
by randyknapp

Description:
Clock is fixed, can choose 12 or 24 hour time.